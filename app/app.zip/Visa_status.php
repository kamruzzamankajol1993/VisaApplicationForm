<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Visa_status extends Model
{
    //
}
